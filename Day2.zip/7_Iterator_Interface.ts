class Queue<T> implements Iterable<T> {
    private _data: T[] = [];

    push(d: T) {
        this._data.push(d);
    }

    pop(): T | undefined {
        return this._data.shift();
    }

    [Symbol.iterator](): Iterator<T> {
        return new DataIterator(this._data);
    }
}

class DataIterator<T> implements Iterator<T> {
    constructor(private _data: T[], private _i = 0) { }

    next(): IteratorResult<T> {
        const self = this;
        let v, d = true;

        if (self._data[this._i] !== undefined) {
            v = self._data[this._i];
            d = false;
            this._i += 1;
        }

        return {
            value: v,
            done: d
        };
    }
}

var numbersQ = new Queue<number>();

numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

for (const item of numbersQ) {
    console.log(item);
}