// Create a method decorator to catch exception
function catchAll<T>(target: T, propertyKey: string, descriptor: any) {
    var originalMethod = descriptor.value;

    descriptor.value = function (...args: any[]) {
        try {
            var result = originalMethod.apply(this, args);
            return result;
        } catch (err) {
            console.log(err.message);
        }
    };

    return descriptor;
}

// ------------------------------------------------------------
// class DAL {
//     @catchAll
//     getCustomers() {
//         // Code to connect to Database and pull data, 
//         // if connection or logic fails we will get exception
//         throw new Error('Exception Thrown!!!');
//     }
// }

// var dObject = new DAL();
// dObject.getCustomers();

// try {
//     var dObject = new DAL();
//     dObject.getCustomers();
// } catch (e) {
//     console.log(e.message);
// }

// ------------------------------------------------------------
class DAL {
    getCustomers() {
        // Code to connect to Database and pull data, 
        // if connection or logic fails we will get exception
        throw new Error('Exception Thrown!!!');
    }
}

class Program {
    @catchAll
    static call(): void {
        var dObject = new DAL();
        dObject.getCustomers();
    }
}

Program.call();