"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var e_1, _a;
var Queue = (function () {
    function Queue() {
        this._data = [];
    }
    Queue.prototype.push = function (d) {
        this._data.push(d);
    };
    Queue.prototype.pop = function () {
        return this._data.shift();
    };
    Queue.prototype[Symbol.iterator] = function () {
        return new DataIterator(this._data);
    };
    return Queue;
}());
var DataIterator = (function () {
    function DataIterator(_data, _i) {
        if (_i === void 0) { _i = 0; }
        this._data = _data;
        this._i = _i;
    }
    DataIterator.prototype.next = function () {
        var self = this;
        var v, d = true;
        if (self._data[this._i] !== undefined) {
            v = self._data[this._i];
            d = false;
            this._i += 1;
        }
        return {
            value: v,
            done: d
        };
    };
    return DataIterator;
}());
var numbersQ = new Queue();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);
try {
    for (var numbersQ_1 = __values(numbersQ), numbersQ_1_1 = numbersQ_1.next(); !numbersQ_1_1.done; numbersQ_1_1 = numbersQ_1.next()) {
        var item = numbersQ_1_1.value;
        console.log(item);
    }
}
catch (e_1_1) { e_1 = { error: e_1_1 }; }
finally {
    try {
        if (numbersQ_1_1 && !numbersQ_1_1.done && (_a = numbersQ_1.return)) _a.call(numbersQ_1);
    }
    finally { if (e_1) throw e_1.error; }
}
//# sourceMappingURL=7_Iterator_Interface.js.map